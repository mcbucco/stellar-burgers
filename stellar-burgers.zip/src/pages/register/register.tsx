import { FC, SyntheticEvent, useState } from 'react';
import { RegisterUI } from '@ui-pages';
import { TRegisterData } from '@api';
import { useDispatch, useSelector } from '../../services/store';
import {
  loginUserSelector,
  registerUser
} from '../../services/slices/user-slice';
import { Preloader } from '@ui';

export const Register: FC = () => {
  const [userName, setUserName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const dispatch = useDispatch();
  const loading = useSelector(loginUserSelector);

  const handleSubmit = (e: SyntheticEvent) => {
    e.preventDefault();

    const newUser: TRegisterData = {
      name: userName,
      email: email,
      password: password
    };
    dispatch(registerUser(newUser));
  };
  if (loading) {
    return <Preloader />;
  }
  return (
    <RegisterUI
      errorText=''
      email={email}
      userName={userName}
      password={password}
      setEmail={setEmail}
      setPassword={setPassword}
      setUserName={setUserName}
      handleSubmit={handleSubmit}
    />
  );
};
