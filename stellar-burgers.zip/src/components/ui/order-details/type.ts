export type OrderDetailsUIProps = {
  orderNumber: number;
};
