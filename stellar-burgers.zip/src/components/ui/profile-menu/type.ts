export type ProfileMenuUIProps = {
  pathname: string;
  handleLogout: () => void;
};
