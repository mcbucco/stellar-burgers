import {
  getUserApi,
  loginUserApi,
  logoutApi,
  registerUserApi,
  TLoginData,
  TRegisterData
} from '@api';
import { createAsyncThunk, createSlice } from '@reduxjs/toolkit';
import { TUser } from '@utils-types';
import { getCookie } from '../../utils/cookie';
import { eraseTokens, setTokens } from '../../utils/utils';

export const getUser = createAsyncThunk('user/get', getUserApi);

export const checkUserAuth = createAsyncThunk(
  'user/checkUser',
  (_, { dispatch }) => {
    if (getCookie('accessToken')) {
      dispatch(getUser()).finally(() => {
        dispatch(authChecked());
      });
    } else {
      dispatch(authChecked());
    }
  }
);

export const registerUser = createAsyncThunk(
  'user/register',
  async (data: TRegisterData) => {
    const regData = await registerUserApi(data);
    setTokens(regData.accessToken, regData.refreshToken);
    return regData.user;
  }
);

export const loginUser = createAsyncThunk(
  'user/login',
  async (data: TLoginData) => {
    const loginData = await loginUserApi(data);
    setTokens(loginData.accessToken, loginData.refreshToken);
    return loginData.user;
  }
);

export const logOutUser = createAsyncThunk('user/logOut', async () => {
  logoutApi();
  eraseTokens();
});

type TUserState = {
  isAuthed: boolean;
  isAuthChecked: boolean;
  user: TUser | null;
  loginError: string | null;
  loginRequest: boolean;
};

const initialState: TUserState = {
  isAuthed: false,
  isAuthChecked: false,
  user: null,
  loginError: null,
  loginRequest: false
};

export const userSlice = createSlice({
  name: 'user',
  initialState,
  reducers: {
    authChecked: (state) => {
      state.isAuthChecked = true;
    }
  },
  extraReducers: (builder) => {
    builder
      .addCase(registerUser.pending, (state) => {
        state.isAuthed = false;
        state.user = null;
        state.loginRequest = true;
      })
      .addCase(registerUser.rejected, (state, action) => {
        state.loginRequest = false;
        state.isAuthed = false;
        state.loginError = action.error.message
          ? action.error.message
          : 'User registration failed';
      })
      .addCase(registerUser.fulfilled, (state, action) => {
        state.isAuthed = true;
        state.loginRequest = false;
        state.user = action.payload;
      })
      .addCase(loginUser.pending, (state) => {
        state.loginRequest = true;
        state.loginError = null;
      })
      .addCase(loginUser.rejected, (state, action) => {
        state.loginRequest = false;
        state.isAuthChecked = true;
        state.loginError = action.error.message
          ? action.error.message
          : 'User log-in failed';
      })
      .addCase(loginUser.fulfilled, (state, action) => {
        state.loginRequest = false;
        state.isAuthChecked = true;
        state.isAuthed = true;
        state.user = action.payload;
      })
      .addCase(logOutUser.pending, (state) => {
        state.loginRequest = true;
        state.isAuthed = true;
      })
      .addCase(logOutUser.rejected, (state, action) => {
        state.isAuthed = false;
        state.loginRequest = false;
        state.loginError = action.error.message
          ? action.error.message
          : 'User log-out failed';
      })
      .addCase(logOutUser.fulfilled, (state, action) => {
        state.isAuthed = false;
        state.user = null;
        state.loginRequest = false;
        eraseTokens();
      });
  },
  selectors: {
    userSelector: (state) => state.user,
    isAuthedSelector: (state) => state.isAuthed,
    isAuthCheckedSelector: (state) => state.isAuthChecked,
    loginUserSelector: (state) => state.loginRequest
  }
});

export const { authChecked } = userSlice.actions;
export const {
  userSelector,
  isAuthedSelector,
  isAuthCheckedSelector,
  loginUserSelector
} = userSlice.selectors;
